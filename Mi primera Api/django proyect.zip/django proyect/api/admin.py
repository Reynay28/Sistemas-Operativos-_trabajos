from django.contrib import admin
from .models import Programmer

# Register your models here.

admin.site.register(Programmer)
