create database prueba04;

use prueba04;

create table persona(
    id int not null,
    name varchar(50) not null,
    age int,
    curp varchar(50),
    rfc varchar(50),
    address varchar(50)
);

select * from persona;